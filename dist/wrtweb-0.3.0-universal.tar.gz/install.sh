#!/bin/sh
# WrtWeb universal installer (works on any OpenWrt: opkg or apk).
# Usage: ./install.sh [DEST]   (default DEST=/)
set -e
DEST="${1:-/}"
HERE=$(cd "$(dirname "$0")" && pwd)
cp -a "$HERE/root/." "$DEST"
chmod +x "$DEST"/usr/libexec/wrtweb/*.sh 2>/dev/null || true
chmod +x "$DEST"/etc/uci-defaults/90-wrtweb 2>/dev/null || true
[ -x "$DEST/etc/init.d/rpcd" ] && "$DEST/etc/init.d/rpcd" restart >/dev/null 2>&1 || true
[ -x "$DEST/etc/init.d/uhttpd" ] && "$DEST/etc/init.d/uhttpd" restart >/dev/null 2>&1 || true
echo "WrtWeb installed. Open https://<router>/wrtweb/"
