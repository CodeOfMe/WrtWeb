WrtWeb universal package. Run ./install.sh as root on the router.
