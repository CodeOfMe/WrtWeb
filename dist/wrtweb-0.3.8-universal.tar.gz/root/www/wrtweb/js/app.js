/* WrtWeb SPA
 * A full GL.iNet-style admin panel implemented as a single-page app.
 * Routes are hash-based (e.g. #/internet, #/clients) and every view talks
 * to the WrtWeb JSON backend at /cgi-bin/wrtweb-api.
 */
(function () {
  "use strict";

  const API_BASE = new URL("../cgi-bin/wrtweb-api", location.href).href;

  /* ---------------- i18n ---------------- */
  let LANG = (function () {
    const qp = new URLSearchParams(location.search).get("lang");
    if (qp === "zh" || qp === "en") { try { localStorage.setItem("wrtweb.lang", qp); } catch (e) {} return qp; }
    return localStorage.getItem("wrtweb.lang") || "en";
  })();
  const I18 = () => (window.I18N[LANG] || window.I18N.en);
  function t(k, scope) {
    const L = I18();
    const s = scope || "common";
    return (L[s] && L[s][k]) || (window.I18N.en[s] && window.I18N.en[s][k]) || k;
  }
  function setLang(l) {
    LANG = l;
    localStorage.setItem("wrtweb.lang", l);
    // persist to router too (best-effort)
    apiPost("system_set", { lang: l === "zh" ? "zh_cn" : "en" }).catch(() => {});
    renderNav();
    render();
  }

  /* ---------------- theme ---------------- */
  function applyTheme(mode) {
    const m = mode || localStorage.getItem("wrtweb.theme") || "auto";
    const sysDark = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
    const dark = m === "dark" || (m === "auto" && sysDark);
    document.documentElement.setAttribute("data-theme", dark ? "dark" : "light");
    const btn = document.getElementById("theme-toggle");
    if (btn) btn.textContent = m === "auto" ? "🌓" : (m === "dark" ? "🌙" : "☀️");
  }
  function cycleTheme() {
    const order = ["auto", "dark", "light"];
    const cur = localStorage.getItem("wrtweb.theme") || "auto";
    const next = order[(order.indexOf(cur) + 1) % order.length];
    localStorage.setItem("wrtweb.theme", next);
    applyTheme(next);
  }

  /* ---------------- api ---------------- */
  async function apiGet(c, params) {
    const u = new URL(API_BASE);
    u.searchParams.set("c", c);
    if (params) for (const k in params) u.searchParams.set(k, params[k]);
    const r = await fetch(u.href, { headers: { Accept: "application/json" } });
    return r.json();
  }
  async function apiPost(c, params) {
    const u = new URL(API_BASE);
    u.searchParams.set("c", c);
    const body = new URLSearchParams(params || {});
    const r = await fetch(u.href, { method: "POST", body });
    return r.json();
  }

  /* ---------------- dom helpers ---------------- */
  const $ = (s, el) => (el || document).querySelector(s);
  // Normalize a possibly-empty Lua table ({} for empty array) to a JS array.
  const arr = (x) => (Array.isArray(x) ? x : []);
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  const fmtB = (n) => {
    n = Number(n) || 0;
    if (n < 1024) return n + " B";
    if (n < 1048576) return (n / 1024).toFixed(1) + " KiB";
    if (n < 1073741824) return (n / 1048576).toFixed(1) + " MiB";
    return (n / 1073741824).toFixed(1) + " GiB";
  };

  function toast(msg, kind) {
    let el = document.createElement("div");
    el.className = "toast " + (kind || "ok");
    el.textContent = msg;
    document.body.appendChild(el);
    requestAnimationFrame(() => el.classList.add("show"));
    setTimeout(() => { el.classList.remove("show"); setTimeout(() => el.remove(), 300); }, 2200);
  }

  function cfgBtn(href) {
    return `<a class="ghost" style="padding:9px 16px;border-radius:9px" href="${href}" target="_blank">${esc(t("configure"))}</a>`;
  }

  function stat(k, v, small, href) {
    const inner = `<div class="k">${esc(k)}</div><div class="v ${small ? "sm" : ""}">${esc(v === "" || v == null ? "-" : String(v))}</div>`;
    return href
      ? `<a class="stat stat-link" href="#/${href}">${inner}<span class="go">›</span></a>`
      : `<div class="stat">${inner}</div>`;
  }

  /* ---------------- nav ---------------- */
  const NAV = [
    { group: "internet", items: [
      { key: "overview", ic: "◎" },
      { key: "internet", ic: "🌐" },
      { key: "repeater", ic: "📶" },
      { key: "hotspot", ic: "📡" },
      { key: "wan", ic: "⇄" },
      { key: "multiwan", ic: "⇉" },
    ]},
    { group: "clients", items: [
      { key: "clients", ic: "👥" },
    ]},
    { group: "apps", items: [
      { key: "plugins", ic: "🧩" },
      { key: "adguard", ic: "🛡" },
      { key: "nas", ic: "💾" },
      { key: "ddns", ic: "🌍" },
      { key: "parental", ic: "👨‍👩‍👧" },
      { key: "tailscale", ic: "⇋" },
      { key: "zerotier", ic: "⓿" },
      { key: "astrowarp", ic: "✦" },
      { key: "edgerouter", ic: "◈" },
    ]},
    { group: "network", items: [
      { key: "wireless", ic: "📶" },
      { key: "lan", ic: "🏠" },
      { key: "guest", ic: "🧑" },
      { key: "dns", ic: "🔤" },
      { key: "ipv6", ic: "6" },
      { key: "firewall", ic: "🧱" },
      { key: "ports", ic: "↦" },
      { key: "vlan", ic: "▤" },
    ]},
    { group: "system", items: [
      { key: "sysinfo", ic: "ℹ" },
      { key: "timezone", ic: "🕒" },
      { key: "logs", ic: "📜" },
      { key: "mirror", ic: "⇅" },
      { key: "remote", ic: "🛰" },
      { key: "storage", ic: "🖴" },
      { key: "upgrade", ic: "⤒" },
      { key: "advanced", ic: "⚙" },
      { key: "security", ic: "🔑" },
      { key: "backup", ic: "🗄" },
      { key: "reboot", ic: "⏻" },
    ]},
    { group: "vpn", collapsed: true, items: [
      { key: "vpn", ic: "🔒" },
      { key: "clash", ic: "◈" },
      { key: "wgclient", ic: "W" },
      { key: "wgserver", ic: "W" },
      { key: "ovpnclient", ic: "O" },
      { key: "ovpnserver", ic: "O" },
      { key: "tor", ic: "T" },
    ]},
  ];

  function navCollapsedState() {
    try { return JSON.parse(localStorage.getItem("wrtweb.collapsed") || "{}"); }
    catch (e) { return {}; }
  }
  function setNavCollapsed(group, val) {
    const s = navCollapsedState(); s[group] = val;
    localStorage.setItem("wrtweb.collapsed", JSON.stringify(s));
  }

  function renderNav() {
    const nav = $("#nav");
    const collapsed = navCollapsedState();
    let html = "";
    for (const g of NAV) {
      if (g.collapsed) {
        const isCol = collapsed[g.group] !== false; // default collapsed
        html += `<details class="nav-group nav-details" data-group="${esc(g.group)}"${isCol ? "" : " open"}>`;
        html += `<summary>${esc(t(g.group, "groups"))}</summary>`;
        for (const it of g.items) {
          html += `<a class="nav-item" data-route="${it.key}" href="#/${it.key}">
            <span class="ic">${it.ic}</span><span>${esc(t(it.key, "nav"))}</span></a>`;
        }
        html += `</details>`;
      } else {
        html += `<div class="nav-group">${esc(t(g.group, "groups"))}</div>`;
        for (const it of g.items) {
          html += `<a class="nav-item" data-route="${it.key}" href="#/${it.key}">
            <span class="ic">${it.ic}</span><span>${esc(t(it.key, "nav"))}</span></a>`;
        }
      }
    }
    nav.innerHTML = html;
    // persist collapsible open/closed state
    nav.querySelectorAll(".nav-details").forEach(d => {
      d.addEventListener("toggle", () =>
        setNavCollapsed(d.getAttribute("data-group"), !d.open));
    });
    const sw = $("#lang-switch");
    if (sw) sw.value = LANG;
  }

  /* ---------------- views ---------------- */
  const VIEWS = {};

  function human(bytes) {
    bytes = Math.max(0, Number(bytes) || 0);
    const u = ["B", "KiB", "MiB", "GiB", "TiB", "PiB"];
    let i = 0, v = bytes;
    while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
    return (v >= 100 ? Math.round(v) : v.toFixed(1)) + " " + u[i];
  }
  const kib = (kb) => human((Number(kb) || 0) * 1024);

  VIEWS.overview = async function () {
    const d = await apiGet("overview");
    const up = d.uptime || 0;
    const uh = Math.floor(up / 3600), um = Math.floor((up % 3600) / 60);
    const diskRows = arr(d.storage).map(s => `<tr>
      <td>${esc(s.target)}</td><td>${esc(s.fs)}</td>
      <td>${kib(s.total)}</td><td>${kib(s.used)}</td><td>${kib(s.avail)}</td>
      <td>${esc(s.pct)}%</td></tr>`).join("");
    const leaseRows = arr(d.leases).map(l => `<tr>
      <td>${esc(l.host || "-")}</td><td>${esc(l.ip)}</td><td class="small">${esc(l.mac)}</td></tr>`).join("");
    const aps = arr(d.wireless).map(w => `<span class="tag">${esc(w.ssid || "-")} · ${esc(w.radio || "")}</span>`).join(" ");
    const tempName = (x) => ({
      cpu: t("cpu_temp", "v"), wifi2g: t("wifi_2g_temp", "v"), wifi5g: t("wifi_5g_temp", "v")
    })[x.key] || x.name || t("temp_other", "v");
    const tempTiles = arr(d.temps).map(x => {
      const c = Number(x.c) || 0;
      const cls = c >= 85 ? "hot" : c >= 70 ? "warm" : "cool";
      return `<div class="stat"><div class="k">${esc(tempName(x))}</div>
        <div class="v temp ${cls}">${c.toFixed(1)} °C</div></div>`;
    }).join("");
    return wrap(`
      <div class="card"><h2>${esc(t("sysinfo", "nav"))}</h2>
        <div class="grid">
          ${stat(t("model"), d.model, false, "sysinfo")}
          ${stat(t("hostname"), d.hostname, false, "timezone")}
          ${stat(t("firmware"), d.firmware, true, "upgrade")}
          ${stat(t("kernel", "v"), d.kernel, true)}
          ${stat(t("localtime", "v"), d.localtime, true)}
          ${stat(t("uptime"), uh + "h " + um + "m", false, "sysinfo")}
          ${stat(t("load"), d.load, false, "sysinfo")}
        </div>
      </div>

      <div class="card"><h2>${esc(t("temperature", "v"))}</h2>
        <div class="grid">${tempTiles || `<p class="muted small">${esc(t("temp_none", "v"))}</p>`}</div>
      </div>

      <div class="card"><h2>${esc(t("memory"))}</h2>
        <div class="grid">
          ${stat(t("used", "v"), kib(d.mem_used) + " / " + kib(d.mem_total) + " (" + (d.mem_pct || 0) + "%)")}
          ${stat(t("available", "v"), kib(d.mem_avail))}
          ${stat(t("free", "v"), kib(d.mem_free))}
          ${stat(t("buffers", "v"), kib(d.mem_buffers))}
          ${stat(t("cached", "v"), kib(d.mem_cached))}
        </div>
      </div>

      <div class="card"><h2>${esc(t("storage_usage", "v"))}</h2>
        <table><thead><tr><th>${esc(t("target", "v"))}</th><th>${esc(t("filesystem", "v"))}</th>
        <th>${esc(t("total", "v"))}</th><th>${esc(t("used", "v"))}</th><th>${esc(t("available", "v"))}</th><th>%</th></tr></thead>
        <tbody>${diskRows || `<tr><td colspan="6" class="muted">${esc(t("none"))}</td></tr>`}</tbody></table>
        <div class="btn-row"><a class="ghost" style="padding:9px 16px;border-radius:9px" href="#/storage">${esc(t("storage", "nav"))} ›</a></div>
      </div>

      <div class="card"><h2>${esc(t("network_wan", "v"))}</h2>
        <div class="grid">
          ${stat(t("wan_ip"), d.wan_ip || "-", false, "wan")}
          ${stat("IPv6", d.wan_ip6 || "-", true, "wan")}
          ${stat(t("protocol", "v"), d.wan_proto || "-")}
          ${stat(t("mac", "v"), d.wan_mac || "-", true)}
          ${stat(t("uptime"), Math.floor((d.wan_uptime || 0) / 60) + "m")}
          ${stat("RX", human(d.wan_rx))}
          ${stat("TX", human(d.wan_tx))}
          ${stat("DNS", d.wan_dns || "-", true)}
          ${stat(t("clients", "nav"), d.clients, false, "clients")}
        </div>
        <div class="btn-row"><a class="ghost" style="padding:9px 16px;border-radius:9px" href="#/wan">${esc(t("wan", "nav"))} ›</a></div>
      </div>

      <div class="card"><h2>${esc(t("dhcp_leases", "v"))} (${arr(d.leases).length})</h2>
        <table><thead><tr><th>${esc(t("hostname"))}</th><th>IP</th><th>${esc(t("mac", "v"))}</th></tr></thead>
        <tbody>${leaseRows || `<tr><td colspan="3" class="muted">${esc(t("none"))}</td></tr>`}</tbody></table>
        <div class="btn-row"><a class="ghost" style="padding:9px 16px;border-radius:9px" href="#/clients">${esc(t("clients", "nav"))} ›</a></div>
      </div>

      <div class="card"><h2>${esc(t("wireless_aps", "v"))} · ${esc(t("stations", "v"))}: ${d.stations || 0}</h2>
        <p>${aps || `<span class="muted">${esc(t("none"))}</span>`}</p>
        <div class="btn-row"><a class="ghost" style="padding:9px 16px;border-radius:9px" href="#/wireless">${esc(t("wireless", "nav"))} ›</a></div>
      </div>

      <div class="card"><h2>${esc(t("system_log", "v"))}</h2>
        <pre class="log">${esc(d.log || "")}</pre>
        <div class="btn-row"><a class="ghost" style="padding:9px 16px;border-radius:9px" href="#/logs">${esc(t("logs", "nav"))} ›</a></div>
      </div>`);
  };

  VIEWS.internet = async function () {
    const [ov, ifc] = await Promise.all([apiGet("overview"), apiGet("network")]);
    const ifrows = arr(ifc.interfaces).map(i => `<tr><td>${esc(i.name)}</td>
      <td><span class="tag ${i.up ? "on" : "off"}">${esc(i.up ? t("on") : t("off"))}</span></td>
      <td>${esc(i.ip || "-")}</td></tr>`).join("");
    return wrap(`
      <div class="card"><h2>${esc(t("internet", "nav"))} · ${esc(t("status"))}</h2>
        <div class="grid">
          ${stat(t("wan_ip"), ov.wan_ip || "-")}
          ${stat(t("wan_proto", "v"), ov.wan_proto || "-")}
          ${stat(t("clients", "nav"), ov.clients || 0)}
        </div>
        <table><thead><tr><th>${esc(t("interfaces", "v"))}</th><th>${esc(t("status"))}</th><th>IP</th></tr></thead>
        <tbody>${ifrows || `<tr><td colspan="3" class="muted">${esc(t("none"))}</td></tr>`}</tbody></table>
        <div class="btn-row">
          <a class="ghost" style="padding:9px 16px;border-radius:9px" href="#/repeater">${esc(t("repeater", "nav"))} ›</a>
          ${cfgBtn("/cgi-bin/luci/admin/network/wireless")}
        </div>
      </div>`);
  };

  VIEWS.repeater = async function () {
    const [s, scan] = await Promise.all([apiGet("repeater_status"), apiGet("repeater_scan")]);
    const c = s.config || {};
    const up = s.uptime || 0;
    const uh = Math.floor(up / 3600), um = Math.floor((up % 3600) / 60);
    const state = s.connected ? t("connected", "v")
      : (c.enabled === "1" ? t("not_associated", "v") : t("disabled"));
    const radios = [];
    const list = arr(scan.networks).map(n => `<div class="list-item">
      <div class="grow"><strong>${esc(n.ssid || "(hidden)")}</strong>
        <div class="small muted">${esc(n.bssid || "")} · ${esc(n.encryption || "")} · ${esc(n.signal || "")} dBm</div></div>
      <button class="ghost" data-join="${esc(n.ssid || "")}" data-enc="${esc(n.encryption || "")}"
        data-bssid="${esc(n.bssid || "")}">${esc(t("connect"))}</button>
    </div>`).join("");

    return wrap(`
      <div class="card"><h2>${esc(t("repeater", "nav"))}</h2>
        <div class="grid">
          ${stat(t("status"), state)}
          ${stat(t("signal", "v"), s.signal ? s.signal + " dBm" : "-")}
          ${stat(t("quality", "v"), s.quality || "-")}
          ${stat(t("uptime"), s.uptime ? (uh ? uh + "h " : "") + um + "m" : "-")}
          ${stat(t("uplink", "v"), s.net_up ? (s.net_ip || t("up", "v")) : t("down", "v"))}
          ${stat(t("auto_reconnect", "v"), s.watch_running ? t("running") : t("stopped"))}
        </div>
        <p class="small muted">${s.iface ? esc(s.iface) + " · " + esc(s.radio || "-") : esc(t("no_sta_iface", "v"))}</p>
        ${s.ap_same_radio ? `<p class="small muted">${esc(t("ap_sta_note", "v"))}</p>` : ""}
        <div class="btn-row">
          <button id="rp-reconnect">${esc(t("reconnect", "v"))}</button>
          <button class="ghost" id="rp-stop">${esc(t("stop", "v"))}</button>
          ${cfgBtn("/cgi-bin/luci/admin/network/wireless")}
        </div>
      </div>
      <div class="card"><h2>${esc(t("join_manually", "v"))}</h2>
        <div class="row">
          <div><label>${esc(t("ssid"))}</label><input id="rp-ssid" value="${esc(c.ssid || "")}"></div>
          <div><label>${esc(t("password"))}</label><input id="rp-key" type="password" value="${esc(c.key || "")}"></div>
          <div><label>${esc(t("encryption", "v"))}</label><select id="rp-enc">
            ${["psk2","sae","psk-mixed","psk","none"].map(e => `<option ${c.encryption === e ? "selected" : ""} value="${e}">${e}</option>`).join("")}
          </select></div>
          <div><label>${esc(t("radio", "v"))}</label><input id="rp-radio" value="${esc(c.radio || "")}" placeholder="radio0"></div>
          <div><label>${esc(t("pin_bssid", "v"))}</label><input id="rp-bssid" value="${esc(c.bssid || "")}" placeholder="${esc(t("optional", "v"))}"></div>
          <div><label>${esc(t("auto_reconnect", "v"))}</label><select id="rp-auto">
            <option value="1" ${c.auto !== "0" ? "selected" : ""}>${esc(t("on"))}</option>
            <option value="0" ${c.auto === "0" ? "selected" : ""}>${esc(t("off"))}</option>
          </select></div>
        </div>
        <div class="btn-row"><button id="rp-join">${esc(t("connect"))}</button></div>
        <p class="small muted">${esc(t("repeater_page_note", "v"))}</p>
      </div>
      <div class="card"><h2>${esc(t("scan"))}</h2>
        <div class="btn-row"><button id="do-scan">${esc(t("scan"))}</button></div>
        <div id="net-list" style="margin-top:12px">${list || `<p class="muted">${esc(t("none"))}</p>`}</div>
      </div>`);
  };
  VIEWS.repeater.mount = function () {
    const join = async (ssid, enc, bssid) => {
      if (!ssid) return toast(t("ssid_required", "v"), "err");
      const r = await apiPost("repeater_join", {
        ssid, key: $("#rp-key").value, encryption: enc,
        radio: $("#rp-radio").value, bssid: bssid || "", auto: $("#rp-auto").value });
      toast(r.ok ? (r.message || t("saved")) : (r.error || t("failed", "v")), r.ok ? "ok" : "err");
      if (r.ok) render();
    };
    const doScan = $("#do-scan");
    if (doScan) doScan.onclick = async () => {
      $("#net-list").innerHTML = `<p class="muted">${esc(t("scanning", "v"))}</p>`;
      const d = await apiGet("repeater_scan");
      $("#net-list").innerHTML = arr(d.networks).map(n => `<div class="list-item">
        <div class="grow"><strong>${esc(n.ssid || "(hidden)")}</strong>
          <div class="small muted">${esc(n.bssid || "")} · ${esc(n.encryption || "")} · ${esc(n.signal || "")} dBm</div></div>
        <button class="ghost" data-join="${esc(n.ssid || "")}" data-enc="${esc(n.encryption || "")}"
          data-bssid="${esc(n.bssid || "")}">${esc(t("connect"))}</button></div>`).join("")
        || `<p class="muted">${esc(t("none"))}</p>`;
      bind();
    };
    const act = async (action) => {
      const r = await apiPost("repeater_action", { action });
      toast(r.ok ? t("saved") : (r.error || t("failed", "v")), r.ok ? "ok" : "err");
      if (r.ok) render();
    };
    const j = $("#rp-join");
    if (j) j.onclick = () => join($("#rp-ssid").value, $("#rp-enc").value, $("#rp-bssid").value);
    const rec = $("#rp-reconnect");
    if (rec) rec.onclick = () => act("reconnect");
    const stop = $("#rp-stop");
    if (stop) stop.onclick = () => act("stop");
    function bind() {
      document.querySelectorAll("[data-join]").forEach(b => {
        b.onclick = () => join(b.getAttribute("data-join"), b.getAttribute("data-enc"), b.getAttribute("data-bssid"));
      });
    }
    bind();
  };

  VIEWS.hotspot = async function () {
    const [mod, wl] = await Promise.all([apiGet("modem"), apiGet("wireless")]);
    const aps = arr(wl.ifaces);
    const protos = ["dhcp", "qmi", "mbim", "ppp"];
    const apCards = aps.map(i => `<div class="card">
      <h2>${esc(i.ssid || i.name)} <span class="tag">${esc(i.device || "")}</span></h2>
      <div class="row">
        <div><label>${esc(t("ssid"))}</label><input data-hf="ssid" data-hsec="${esc(i.name)}" value="${esc(i.ssid || "")}"></div>
        <div><label>${esc(t("password"))}</label><input data-hf="key" data-hsec="${esc(i.name)}" type="password" value="${esc(i.key || "")}"></div>
      </div>
      <div class="btn-row"><button data-hsave="${esc(i.name)}">${esc(t("save"))}</button></div>
    </div>`).join("");
    return wrap(`
      <div class="card"><h2>${esc(t("modem_title", "v"))}</h2>
        <div class="grid">
          ${stat(t("detected", "v"), mod.detected || t("none"))}
          ${stat(t("status"), mod.enabled === "1" ? t("enabled") : t("disabled"))}
        </div>
        <div class="row">
          <div><label>${esc(t("protocol", "v"))}</label><select id="hf-proto">
            ${protos.map(p => `<option ${mod.proto === p ? "selected" : ""} value="${p}">${p.toUpperCase()}</option>`).join("")}
          </select></div>
          <div><label>${esc(t("apn", "v"))}</label><input id="hf-apn" value="${esc(mod.apn || "")}"></div>
        </div>
        <div class="btn-row">
          <button id="hf-on">${esc(t("enable_share", "v"))}</button>
          <button class="ghost" id="hf-off">${esc(t("disabled"))}</button>
          ${cfgBtn("/cgi-bin/luci/admin/network/wireless")}
        </div>
        <p class="muted small">${esc(t("modem_note", "v"))}</p>
      </div>
      <div class="card"><h2>${esc(t("wifi_hotspot", "v"))}</h2>
        <p class="muted small">${esc(t("tethering", "v"))} — LAN devices join this Wi-Fi and share the uplink.</p>
      </div>
      ${apCards || `<div class="card muted">${esc(t("no_wireless", "v"))}</div>`}
    `);
  };
  VIEWS.hotspot.mount = function () {
    const on = $("#hf-on"), off = $("#hf-off");
    if (on) on.onclick = async () => {
      const r = await apiPost("modem_set", { enabled: "1", proto: $("#hf-proto").value, apn: $("#hf-apn").value });
      toast(r.ok ? t("saved") : t("failed", "v"), r.ok ? "ok" : "err");
    };
    if (off) off.onclick = async () => {
      const r = await apiPost("modem_set", { enabled: "0" });
      toast(r.ok ? t("saved") : t("failed", "v"), r.ok ? "ok" : "err");
    };
    document.querySelectorAll("[data-hsave]").forEach(b => {
      b.onclick = async () => {
        const sec = b.getAttribute("data-hsave");
        const p = { iface: sec };
        document.querySelectorAll(`[data-hsec="${sec}"]`).forEach(inp => p[inp.getAttribute("data-hf")] = inp.value);
        const r = await apiPost("wireless_set", p);
        toast(r.ok ? t("saved") : t("failed", "v"), r.ok ? "ok" : "err");
      };
    });
  };

  VIEWS.wan = async function () {
    const d = await apiGet("wan");
    return wrap(`
      <div class="card"><h2>${esc(t("wan", "v"))}</h2>
        <div class="row">
          <div><label>${esc(t("protocol", "v"))}</label><select id="w-proto">
            ${["dhcp","static","pppoe"].map(p => `<option ${d.proto===p?"selected":""} value="${p}">${p.toUpperCase()}</option>`).join("")}
          </select></div>
        </div>
        <div class="row">
          <div><label>${esc(t("pppoe_user_static", "v"))}</label><input id="w-user" value="${esc(d.username||d.ipaddr||"")}"></div>
          <div><label>${esc(t("password_netmask", "v"))}</label><input id="w-pass" value="${esc(d.netmask||"")}"></div>
          <div><label>${esc(t("gateway", "v"))}</label><input id="w-gw" value="${esc(d.gateway||"")}"></div>
        </div>
        <div class="btn-row"><button id="w-save">${esc(t("save"))}</button>${cfgBtn("/cgi-bin/luci/admin/network/network")}</div>
        <p class="muted small">${esc(t("current_wan_ip", "v"))}: ${esc(d.ip||"-")}</p>
      </div>`);
  };
  VIEWS.wan.mount = function () {
    $("#w-save").onclick = async () => {
      const proto = $("#w-proto").value;
      const p = { proto };
      if (proto === "pppoe") { p.username = $("#w-user").value; p.password = $("#w-pass").value; }
      if (proto === "static") { p.ipaddr = $("#w-user").value; p.netmask = $("#w-pass").value; p.gateway = $("#w-gw").value; }
      const r = await apiPost("wan_set", p);
      toast(r.ok ? t("saved") : t("failed", "v"), r.ok ? "ok" : "err");
    };
  };

  VIEWS.clients = async function () {
    const d = await apiGet("clients");
    const sigTag = (s) => {
      if (s == null) return "-";
      const cls = (s >= -60 ? "on" : (s >= -75 ? "" : "off"));
      return `<span class="tag ${cls}">${s} dBm</span>`;
    };
    const rows = arr(d.clients).map(c => {
      let conn;
      if (c.method === "wifi") {
        conn = `<span class="tag">${esc(t("wifi", "v"))}${c.band ? " " + esc(c.band) : ""}`
          + (c.channel ? " ch" + esc(c.channel) : "") + (c.width ? " " + esc(c.width) : "") + "</span>";
      } else {
        conn = `<span class="tag">${esc(t("wired", "v"))}`
          + (c.port ? " " + esc(c.port) : "")
          + (c.speed ? " " + esc(c.speed) + "M " + esc(c.duplex || "") : "") + "</span>";
      }
      const rate = (c.tx != null || c.rx != null)
        ? `${c.tx != null ? c.tx : "-"} / ${c.rx != null ? c.rx : "-"} Mbit/s` : "-";
      return `<tr>
        <td>${esc(c.name || "-")}</td>
        <td>${esc(c.ip || "-")}</td>
        <td class="small">${esc(c.mac || "")}</td>
        <td>${conn}</td>
        <td>${c.method === "wifi" ? sigTag(c.signal) + (c.quality ? ` <span class="tag ${esc(c.quality)}">${esc(t(c.quality, "v"))}</span>` : "") : "-"}</td>
        <td class="small">${esc(rate)}</td>
        <td class="small">${c.traffic ? `${fmtB(c.traffic.up)} ↑ ${fmtB(c.traffic.down)} ↓` : "-"}</td>
        <td>${c.online ? `<span class="tag on">${esc(t("online", "v"))}</span>` : `<span class="tag off">${esc(t("offline", "v"))}</span>`}${c.state ? ` <span class="small muted">${esc(c.state)}</span>` : ""}</td>
      </tr>`;
    }).join("");
    return wrap(`<div class="card"><h2>${esc(t("clients", "nav"))}</h2>
      <div class="grid">
        ${stat(t("total", "v"), d.total || 0)}
        ${stat(t("wifi", "v"), d.wifi || 0)}
        ${stat(t("wired", "v"), d.wired || 0)}
      </div>
      <table><thead><tr><th>${esc(t("name"))}</th><th>IP</th><th>${esc(t("mac", "v"))}</th>
      <th>${esc(t("method", "v"))}</th><th>${esc(t("signal", "v"))}</th><th>${esc(t("rate", "v"))}</th>
      <th>${esc(t("traffic", "v"))}</th><th>${esc(t("status"))}</th></tr></thead><tbody>
      ${rows || `<tr><td colspan="8" class="muted">${esc(t("none"))}</td></tr>`}</tbody></table>
      <p class="small muted">${esc(t("clients_note", "v"))}</p>
      <div class="btn-row">${cfgBtn("/cgi-bin/luci/admin/network/network")}</div></div>`);
  };

  VIEWS.wireless = async function () {
    const d = await apiGet("wireless");
    const ifaces = arr(d.ifaces).map(i => `<div class="card">
      <h2>${esc(i.ssid || i.name)} <span class="tag">${esc(i.band || i.device || "")}</span>
        <span class="tag ${i.stations ? "on" : ""}">${esc(t("stations", "v"))}: ${esc(i.stations || 0)}</span></h2>
      <p class="small muted">${esc(i.iface || t("unknown", "v"))} · ${esc(t("channel", "v"))} ${esc(i.channel || "-")}${i.width ? " · " + esc(i.width) + " MHz" : ""}${i.txpower ? " · " + esc(i.txpower) + " dBm" : ""}</p>
      <div class="row">
        <div><label>${esc(t("ssid"))}</label><input data-f="ssid" data-sec="${esc(i.name)}" value="${esc(i.ssid||"")}"></div>
        <div><label>${esc(t("password"))}</label><input data-f="key" data-sec="${esc(i.name)}" type="password" value="${esc(i.key||"")}"></div>
        <div><label>${esc(t("encryption", "v"))}</label><select data-f="encryption" data-sec="${esc(i.name)}">
          ${["psk2","sae","sae-mixed","psk-mixed","none"].map(e=>`<option ${i.encryption===e?"selected":""} value="${e}">${e}</option>`).join("")}
        </select></div>
      </div>
      <div class="btn-row"><button data-save-sec="${esc(i.name)}">${esc(t("save"))}</button></div>
    </div>`).join("");
    return wrap((ifaces || `<div class="muted">${esc(t("no_wireless", "v"))}</div>`) + `<div class="btn-row">${cfgBtn("/cgi-bin/luci/admin/network/wireless")}</div>`);
  };
  VIEWS.wireless.mount = function () {
    document.querySelectorAll("[data-save-sec]").forEach(btn => {
      btn.onclick = async () => {
        const sec = btn.getAttribute("data-save-sec");
        const p = { iface: sec };
        document.querySelectorAll(`[data-sec="${sec}"]`).forEach(inp => p[inp.getAttribute("data-f")] = inp.value);
        const r = await apiPost("wireless_set", p);
        toast(r.ok ? t("saved") : t("failed", "v"), r.ok ? "ok" : "err");
      };
    });
  };

  VIEWS.lan = async function () {
    const d = await apiGet("lan");
    return wrap(`<div class="card"><h2>${esc(t("lan", "nav"))}</h2>
      <div class="row">
        <div><label>IP</label><input id="l-ip" value="${esc(d.ipaddr||"")}"></div>
        <div><label>${esc(t("netmask", "v"))}</label><input id="l-mask" value="${esc(d.netmask||"")}"></div>
        <div><label>${esc(t("dhcp_start", "v"))}</label><input id="l-s" value="${esc(d.dhcp_start||"")}"></div>
        <div><label>${esc(t("dhcp_limit", "v"))}</label><input id="l-l" value="${esc(d.dhcp_limit||"")}"></div>
      </div>
      <div class="btn-row"><button id="l-save">${esc(t("save"))}</button>${cfgBtn("/cgi-bin/luci/admin/network/network")}</div>
      <p class="muted small">${esc(t("lan_note", "v"))}</p></div>`);
  };
  VIEWS.lan.mount = function () {
    $("#l-save").onclick = async () => {
      const r = await apiPost("lan_set", { ipaddr:$("#l-ip").value, netmask:$("#l-mask").value,
        dhcp_start:$("#l-s").value, dhcp_limit:$("#l-l").value });
      toast(r.ok ? t("saved") : t("failed", "v"), r.ok ? "ok" : "err");
    };
  };

  VIEWS.guest = async function () {
    const d = await apiGet("wireless");
    const guest = arr(d.ifaces).find(i => i.network === "guest");
    return wrap(`<div class="card"><h2>${esc(t("guest", "nav"))}</h2>
      <p class="muted small">${esc(t("guest_note", "v"))}</p>
      <div class="row">
        <div><label>${esc(t("ssid"))}</label><input id="g-ssid" value="${esc(guest?guest.ssid:"guest")}"></div>
        <div><label>${esc(t("password"))}</label><input id="g-key" type="password" value="${esc(guest?guest.key:"")}"></div>
      </div>
      <div class="btn-row"><button id="g-save">${esc(t("save"))}</button>${cfgBtn("/cgi-bin/luci/admin/network/wireless")}</div>
      <p class="muted small">${esc(t("guest_apply_note", "v"))}</p>
    </div>`);
  };
  VIEWS.guest.mount = function () {
    $("#g-save").onclick = async () => {
      const r = await apiPost("guest_apply", { ssid:$("#g-ssid").value, key:$("#g-key").value, encryption:"psk2", isolate:"1" });
      toast(r.ok ? t("saved") : t("failed", "v"), r.ok ? "ok" : "err");
    };
  };

  VIEWS.ports = async function () {
    const d = await apiGet("portforward");
    const rows = arr(d.rules).map(r => `<tr>
      <td>${esc(r.name)}</td><td>${esc(r.proto)}</td><td>${esc(r.src_dport)}</td>
      <td>${esc(r.dest_ip)}:${esc(r.dest_port)}</td>
      <td><button class="ghost" data-del="${r.idx}">${esc(t("remove"))}</button></td></tr>`).join("");
    return wrap(`<div class="card"><h2>${esc(t("ports", "nav"))}</h2>
      <table><thead><tr><th>${esc(t("name"))}</th><th>${esc(t("proto", "v"))}</th><th>${esc(t("ext_port", "v"))}</th><th>${esc(t("internal", "v"))}</th><th></th></tr></thead>
      <tbody>${rows || `<tr><td colspan="5" class="muted">${esc(t("none"))}</td></tr>`}</tbody></table></div>
      <div class="card"><h2>${esc(t("add"))}</h2>
        <div class="row">
          <div><label>${esc(t("name"))}</label><input id="p-name"></div>
          <div><label>${esc(t("proto", "v"))}</label><select id="p-proto"><option>tcp</option><option>udp</option><option>tcp udp</option></select></div>
          <div><label>${esc(t("ext_port", "v"))}</label><input id="p-sport"></div>
          <div><label>${esc(t("internal_ip", "v"))}</label><input id="p-ip"></div>
          <div><label>${esc(t("internal_port", "v"))}</label><input id="p-dport"></div>
        </div>
        <div class="btn-row"><button id="p-add">${esc(t("add"))}</button>${cfgBtn("/cgi-bin/luci/admin/network/firewall")}</div></div>`);
  };
  VIEWS.ports.mount = function () {
    $("#p-add").onclick = async () => {
      const r = await apiPost("portforward_add", { name:$("#p-name").value, proto:$("#p-proto").value,
        src_dport:$("#p-sport").value, dest_ip:$("#p-ip").value, dest_port:$("#p-dport").value });
      if (r.ok) { toast(t("saved")); render(); } else toast(t("failed", "v"), "err");
    };
    document.querySelectorAll("[data-del]").forEach(b => {
      b.onclick = async () => {
        const r = await apiPost("portforward_del", { idx: b.getAttribute("data-del") });
        if (r.ok) { toast(t("saved")); render(); } else toast(t("failed", "v"), "err");
      };
    });
  };

  VIEWS.adguard = async function () {
    const d = await apiGet("adguard");
    return wrap(`<div class="card"><h2>${esc(t("adguard", "nav"))}</h2>
      <div class="grid">
        ${stat(t("package", "v"), d.installed ? t("installed") : t("not_installed"))}
        ${stat(t("status"), d.running ? t("running") : t("stopped"))}
      </div>
      <div class="btn-row">
        <button id="ag-start">${esc(t("start", "v"))}</button>
        <button class="ghost" id="ag-stop">${esc(t("stop", "v"))}</button>
        <a class="ghost" style="padding:9px 16px;border-radius:9px" href="http://${esc(location.hostname)}:3000" target="_blank">${esc(t("open_ui", "v"))}</a>
        ${cfgBtn("/cgi-bin/luci/admin/services/adguardhome")}
      </div>
      <p class="muted small">${esc(t("ag_note", "v"))}</p>
    </div>`);
  };
  VIEWS.adguard.mount = function () {
    $("#ag-start").onclick = async () => { const r = await apiPost("adguard_set",{action:"start"}); toast(r.ok?t("started","v"):t("failed","v"),r.ok?"ok":"err"); };
    $("#ag-stop").onclick = async () => { const r = await apiPost("adguard_set",{action:"stop"}); toast(r.ok?t("stopped","v"):t("failed","v"),r.ok?"ok":"err"); };
  };

  VIEWS.nas = async function () {
    const [d, su] = await Promise.all([apiGet("nas"), apiGet("samba_users")]);
    const users = arr(su.users);
    const userRows = users.map(x => `<div style="border-bottom:1px solid var(--line);padding:10px 0">
      <div class="row">
        <div><label>${esc(t("username", "v"))}</label><input value="${esc(x.name)}" readonly></div>
        <div><label>${esc(t("storage_path", "v"))}</label><input data-su-path="${esc(x.name)}" value="${esc(x.path || ("/mnt/nvme/" + x.name))}"></div>
      </div>
      <div class="btn-row">
        <button data-su-assign="${esc(x.name)}">${esc(t("assign", "v"))}</button>
        <button class="ghost" data-su-del="${esc(x.name)}">${esc(t("remove"))}</button>
      </div></div>`).join("");
    return wrap(`
      <div class="card"><h2>${esc(t("nas", "nav"))}</h2>
        <div class="grid">${stat(t("samba", "v"), d.samba_enabled === "1" ? t("enabled") : t("disabled"))}</div>
        <p class="small muted">${esc(t("mounts", "v"))}: ${esc(d.mounts || "-")}</p>
        <div class="btn-row">
          <button id="nas-on">${esc(t("enabled"))}</button>
          <button class="ghost" id="nas-off">${esc(t("disabled"))}</button>
          ${cfgBtn("/cgi-bin/luci/admin/services/samba4")}
        </div>
        <p class="muted small">${esc(t("nas_note", "v"))}</p>
      </div>
      <div class="card"><h2>${esc(t("samba_users", "v"))}</h2>
        <div>${userRows || `<div class="muted">${esc(t("none"))}</div>`}</div>
        <div class="row">
          <div><label>${esc(t("username", "v"))}</label><input id="su-user" autocomplete="off"></div>
          <div><label>${esc(t("password"))}</label><input id="su-pass" type="password" autocomplete="new-password"></div>
          <div><label>${esc(t("storage_path", "v"))}</label><input id="su-path" placeholder="/mnt/nvme/user"></div>
        </div>
        <div class="btn-row"><button id="su-add">${esc(t("add_user", "v"))}</button></div>
        <p class="muted small">${esc(t("samba_users_note", "v"))}</p>
      </div>`);
  };
  VIEWS.nas.mount = function () {
    const on = $("#nas-on"), off = $("#nas-off");
    if (on) on.onclick = async () => { const r = await apiPost("nas_set", { enabled: "1" }); toast(r.ok ? t("saved") : t("failed", "v"), r.ok ? "ok" : "err"); render(); };
    if (off) off.onclick = async () => { const r = await apiPost("nas_set", { enabled: "0" }); toast(r.ok ? t("saved") : t("failed", "v"), r.ok ? "ok" : "err"); render(); };
    const add = $("#su-add");
    if (add) add.onclick = async () => {
      const user = $("#su-user").value.trim(), pass = $("#su-pass").value;
      const path = $("#su-path") ? $("#su-path").value.trim() : "";
      if (!user) return toast(t("username", "v"), "err");
      if (pass.length < 5) return toast(t("pw_min", "v"), "err");
      const r = await apiPost("samba_user_add", { user, pass, path });
      toast(r.ok ? t("saved") : (r.error || t("failed", "v")), r.ok ? "ok" : "err");
      if (r.ok) render();
    };
    document.querySelectorAll("[data-su-assign]").forEach(b => {
      b.onclick = async () => {
        const u = b.getAttribute("data-su-assign");
        const inp = document.querySelector(`[data-su-path="${u}"]`);
        const r = await apiPost("samba_assign", { user: u, path: inp ? inp.value.trim() : "" });
        toast(r.ok ? t("saved") : (r.error || t("failed", "v")), r.ok ? "ok" : "err");
        if (r.ok) render();
      };
    });
    document.querySelectorAll("[data-su-del]").forEach(b => {
      b.onclick = async () => {
        const r = await apiPost("samba_user_del", { user: b.getAttribute("data-su-del") });
        toast(r.ok ? t("saved") : t("failed", "v"), r.ok ? "ok" : "err");
        if (r.ok) render();
      };
    });
  };

  VIEWS.ddns = async function () {
    const d = await apiGet("ddns");
    const rows = arr(d.services).map(s=>`<tr><td>${esc(s.service || "-")}</td><td>${esc(s.domain || "-")}</td><td><span class="tag ${s.enabled === "1" ? "on" : "off"}">${esc(s.enabled === "1" ? t("on") : t("off"))}</span></td></tr>`).join("");
    return wrap(`<div class="card"><h2>${esc(t("ddns", "nav"))}</h2>
      <table><thead><tr><th>${esc(t("service", "v"))}</th><th>${esc(t("domain", "v"))}</th><th>${esc(t("enabled"))}</th></tr></thead>
      <tbody>${rows||`<tr><td colspan="3" class="muted">${esc(t("none"))}</td></tr>`}</tbody></table>
      <p class="muted small">${esc(t("ddns_note", "v"))}</p>
      <div class="btn-row">${cfgBtn("/cgi-bin/luci/admin/services/ddns")}</div></div>`);
  };

  VIEWS.vpn = async function () {
    const d = await apiGet("vpn");
    const wg = arr(d.wireguard).map(w=>`<tr><td>${esc(w.iface)}</td><td>${esc(w.peers)}</td></tr>`).join("");
    return wrap(`<div class="card"><h2>${esc(t("vpn", "nav"))}</h2>
      <div class="grid">
        ${stat("WireGuard", d.wg_installed ? t("installed") : t("not_installed"))}
        ${stat("OpenVPN", d.ovpn_installed ? t("installed") : t("not_installed"))}
        ${stat(t("ovpn_profiles", "v"), d.ovpn_count)}
      </div>
      <table style="margin-top:12px"><thead><tr><th>${esc(t("wg_iface", "v"))}</th><th>${esc(t("peers", "v"))}</th></tr></thead>
      <tbody>${wg||`<tr><td colspan="2" class="muted">${esc(t("none"))}</td></tr>`}</tbody></table>
      <div class="btn-row">${cfgBtn("/cgi-bin/luci/admin/network/network")}</div></div>`);
  };

  VIEWS.clash = async function () {
    const d = await apiGet("clash");
    return wrap(`<div class="card"><h2>${esc(t("clash", "nav"))}</h2>
      <div class="grid">
        ${stat(t("package", "v"), d.installed ? t("installed") : t("not_installed"))}
        ${stat(t("status"), d.running ? t("running") : t("stopped"))}
      </div>
      ${d.installed ? `<div class="btn-row">
        <button data-clash="start">${esc(t("start", "v"))}</button>
        <button class="ghost" data-clash="stop">${esc(t("stop", "v"))}</button>
        <a class="ghost" style="padding:9px 16px;border-radius:9px" href="http://${location.hostname}:9090/ui/">${esc(t("open_ui", "v"))}</a>
      </div>` : ""}
      <p class="muted small">${esc(t("clash_note", "v"))}</p>
    </div>`);
  };
  VIEWS.clash.mount = function () {
    document.querySelectorAll("[data-clash]").forEach(b => {
      b.onclick = async () => {
        const r = await apiPost("clash_set", { action: b.getAttribute("data-clash") });
        toast(r.ok ? t("saved") : (r.error || t("failed", "v")), r.ok ? "ok" : "err");
        if (r.ok) render();
      };
    });
  };

  VIEWS.remote = async function () {
    const [d, s] = await Promise.all([apiGet("remote_access"), apiGet("remote_ssh")]);
    const url = "https://" + (d.wan_ip || location.hostname) + "/wrtweb/";
    const sshcmd = "ssh root@" + (s.wan_ip || location.hostname);
    return wrap(`
      <div class="card"><h2>${esc(t("remote", "nav"))}</h2>
        <p class="muted small">${esc(t("remote_note", "v"))}</p>
        <div class="grid">
          ${stat(t("status"), d.enabled ? t("enabled") : t("disabled"))}
          ${stat("WAN", d.wan_ip || "-")}
        </div>
        <div class="row"><div><label>${esc(t("remote_url", "v"))}</label><input readonly value="${esc(url)}"></div></div>
        <div class="btn-row">
          <button id="ra-on">${esc(t("enabled"))}</button>
          <button class="ghost" id="ra-off">${esc(t("disabled"))}</button>
          ${cfgBtn("/cgi-bin/luci/admin/network/firewall")}
        </div>
      </div>
      <div class="card"><h2>${esc(t("ssh_wan", "v"))}</h2>
        <p class="muted small">${esc(t("ssh_note", "v"))}</p>
        <div class="grid">${stat(t("status"), s.enabled ? t("enabled") : t("disabled"))}</div>
        <div class="row"><div><label>${esc(t("remote_url", "v"))}</label><input readonly value="${esc(sshcmd)}"></div></div>
        <div class="btn-row">
          <button id="ssh-on">${esc(t("enabled"))}</button>
          <button class="ghost" id="ssh-off">${esc(t("disabled"))}</button>
        </div>
      </div>`);
  };
  VIEWS.remote.mount = function () {
    $("#ra-on").onclick = async () => { const r = await apiPost("remote_access_set", { enabled: "1" }); toast(r.ok ? t("saved") : t("failed", "v"), r.ok ? "ok" : "err"); render(); };
    $("#ra-off").onclick = async () => { const r = await apiPost("remote_access_set", { enabled: "0" }); toast(r.ok ? t("saved") : t("failed", "v"), r.ok ? "ok" : "err"); render(); };
    const so = $("#ssh-on"), sf = $("#ssh-off");
    if (so) so.onclick = async () => { const r = await apiPost("remote_ssh_set", { enabled: "1" }); toast(r.ok ? t("saved") : t("failed", "v"), r.ok ? "ok" : "err"); render(); };
    if (sf) sf.onclick = async () => { const r = await apiPost("remote_ssh_set", { enabled: "0" }); toast(r.ok ? t("saved") : t("failed", "v"), r.ok ? "ok" : "err"); render(); };
  };

  VIEWS.storage = async function () {
    const d = await apiGet("storage");
    return wrap(`
      <div class="card"><h2>${esc(t("storage", "nav"))}</h2>
        <p class="muted small">${esc(t("storage_note", "v"))}</p>
        <div class="grid">
          ${stat(t("overlay_now", "v"), d.overlay || "-", true)}
          ${stat(t("nvme_part", "v"), (d.fstype || "?") + " " + (d.uuid || ""), true)}
          ${stat(t("status"), d.extroot ? t("extroot_on", "v") : t("extroot_off", "v"))}
        </div>
        <div class="btn-row">
          ${d.extroot
            ? `<button class="danger" id="st-rollback">${esc(t("rollback_btn", "v"))}</button>`
            : `<button id="st-migrate">${esc(t("migrate_btn", "v"))}</button>`}
        </div>
        <p class="muted small">${esc(t("storage_warn", "v"))}</p>
      </div>`);
  };
  VIEWS.storage.mount = function () {
    const m = $("#st-migrate");
    if (m) m.onclick = async () => {
      if (!confirm(t("migrate_confirm", "v"))) return;
      const r = await apiPost("storage_migrate", { confirm: "1" });
      if (r.ok) toast(t("reboot_now", "v")); else toast(r.error || t("failed", "v"), "err");
    };
    const rb = $("#st-rollback");
    if (rb) rb.onclick = async () => {
      if (!confirm(t("migrate_confirm", "v"))) return;
      const r = await apiPost("storage_rollback", {});
      if (r.ok) toast(t("reboot_now", "v")); else toast(r.error || t("failed", "v"), "err");
    };
  };

  VIEWS.mirror = async function () {
    const d = await apiGet("mirror");
    return wrap(`<div class="card"><h2>${esc(t("mirror", "nav"))}</h2>
      <p class="muted small">${esc(t("mirror_note", "v"))}</p>
      <div class="grid">${stat(t("current_source", "v"), d.host || "-", true)}</div>
      <div class="row">
        <div><label>${esc(t("select_source", "v"))}</label>
          <select id="mir-mode">
            <option value="auto">${esc(t("auto", "v"))}</option>
            <option value="tuna">TUNA (Tsinghua)</option>
            <option value="ustc">USTC</option>
            <option value="official">${esc(t("official", "v"))}</option>
          </select></div>
      </div>
      <div class="btn-row"><button id="mir-apply">${esc(t("apply"))}</button></div>
      <pre class="log" id="mir-out"></pre>
    </div>`);
  };
  VIEWS.mirror.mount = function () {
    $("#mir-apply").onclick = async () => {
      const mode = $("#mir-mode").value;
      const r = await apiPost("mirror_set", { mode });
      toast(r.ok ? t("saved") : t("failed", "v"), r.ok ? "ok" : "err");
      if (r.output) $("#mir-out").textContent = r.output;
    };
  };

  VIEWS.plugins = async function () {
    const d = await apiGet("plugins");
    const pkgs = arr(d.packages);
    const rows = pkgs.slice(0, 500).map(p=>`<tr><td class="small">${esc(p)}</td></tr>`).join("");
    return wrap(`<div class="card"><h2>${esc(t("plugins", "nav"))} (${d.count||0})</h2>
      <pre class="log">${esc(pkgs.join("\n"))}</pre>
      <div class="btn-row">${cfgBtn("/cgi-bin/luci/admin/system/package-manager")}</div></div>`);
  };

  VIEWS.sysinfo = async function () {
    return VIEWS.overview();
  };

  VIEWS.logs = async function () {
    const d = await apiGet("logs");
    return wrap(`<div class="card"><h2>${esc(t("logs", "nav"))}</h2>
      <div class="btn-row"><button id="log-refresh">${esc(t("refresh"))}</button>${cfgBtn("/cgi-bin/luci/admin/status/logs")}</div>
      <pre class="log" id="logbox">${esc(d.syslog||"")}</pre></div>`);
  };
  VIEWS.logs.mount = function () { const b=$("#log-refresh"); if(b) b.onclick = () => render(); };

  VIEWS.timezone = async function () {
    const d = await apiGet("system");
    const zones = ["UTC","Asia/Shanghai","Asia/Hong_Kong","Asia/Taipei","Asia/Tokyo","America/New_York","Europe/London","Europe/Berlin"];
    return wrap(`<div class="card"><h2>${esc(t("timezone", "nav"))} / ${esc(t("hostname"))}</h2>
      <div class="row">
        <div><label>${esc(t("hostname"))}</label><input id="tz-host" value="${esc(d.hostname||"")}"></div>
        <div><label>${esc(t("time_zone", "v"))}</label><select id="tz-zone">
          ${zones.map(z=>`<option ${d.timezone===z?"selected":""} value="${z}">${z}</option>`).join("")}
        </select></div>
      </div>
      <div class="btn-row"><button id="tz-save">${esc(t("save"))}</button>${cfgBtn("/cgi-bin/luci/admin/system/system")}</div></div>`);
  };
  VIEWS.timezone.mount = function () {
    $("#tz-save").onclick = async () => {
      const r = await apiPost("system_set", { hostname:$("#tz-host").value, timezone:$("#tz-zone").value });
      toast(r.ok?t("saved"):t("failed", "v"), r.ok?"ok":"err");
    };
  };

  VIEWS.reboot = async function () {
    return wrap(`<div class="card"><h2>${esc(t("reboot", "nav"))}</h2>
      <p class="muted">${esc(t("reboot_device", "v"))}</p>
      <div class="btn-row"><button class="danger" id="rb">${esc(t("reboot", "nav"))}</button></div></div>`);
  };
  VIEWS.reboot.mount = function () {
    $("#rb").onclick = async () => {
      if (!confirm(t("reboot_confirm"))) return;
      await apiPost("reboot", { confirm:"1" });
      toast(t("reboot_now", "v"));
    };
  };

  /* ---------- real feature pages (status + control) ---------- */
  function serviceBtns(svc, cfg) {
    return `<div class="btn-row">
      <button data-svc="${svc}" data-act="start">${esc(t("start", "v"))}</button>
      <button class="ghost" data-svc="${svc}" data-act="stop">${esc(t("stop", "v"))}</button>
      <button class="ghost" data-svc="${svc}" data-act="restart">${esc(t("restart"))}</button>
      ${cfg ? cfgBtn(cfg) : ""}
    </div>`;
  }
  function bindSvc() {
    document.querySelectorAll("[data-svc]").forEach(b => {
      b.onclick = async () => {
        const r = await apiPost("service_set", { s: b.getAttribute("data-svc"), action: b.getAttribute("data-act") });
        toast(r.ok ? t("saved") : t("failed", "v"), r.ok ? "ok" : "err");
        render();
      };
    });
  }
  function serviceView(key, pkg, cfg) {
    const fn = async function () {
      const d = await apiGet("service", { s: key });
      return wrap(`<div class="card"><h2>${esc(t(key, "nav"))}</h2>
        <div class="grid">
          ${stat(t("package", "v"), d.installed ? t("installed") : t("not_installed"))}
          ${stat(t("status"), d.running ? t("running") : t("stopped"))}
        </div>
        ${serviceBtns(key, cfg)}
        ${!d.installed ? `<p class="small muted">${esc(t("requires_pkg", "v"))}: <code>${esc(pkg || "")}</code></p>` : ""}
      </div>`);
    };
    fn.mount = bindSvc;
    return fn;
  }

  VIEWS.multiwan = async function () {
    const d = await apiGet("mwan");
    return wrap(`<div class="card"><h2>${esc(t("multiwan", "nav"))}</h2>
      <div class="grid">
        ${stat(t("package", "v"), d.installed ? t("installed") : t("not_installed"))}
        ${stat(t("status"), d.running ? t("running") : t("stopped"))}
      </div>
      ${serviceBtns("mwan3", "/cgi-bin/luci/admin/network/mwan3")}
      <pre class="log">${esc(d.status || d.interfaces || t("none"))}</pre>
    </div>`);
  };
  VIEWS.multiwan.mount = bindSvc;

  VIEWS.wgclient = async function () {
    const d = await apiGet("vpn");
    const rows = arr(d.wireguard).map(w => `<tr><td>${esc(w.iface)}</td><td>${esc(w.peers)}</td></tr>`).join("");
    return wrap(`<div class="card"><h2>${esc(t("wgclient", "nav"))}</h2>
      <div class="grid">${stat("WireGuard", d.wg_installed ? t("installed") : t("not_installed"))}</div>
      <table><thead><tr><th>${esc(t("wg_iface", "v"))}</th><th>${esc(t("peers", "v"))}</th></tr></thead>
      <tbody>${rows || `<tr><td colspan="2" class="muted">${esc(t("none"))}</td></tr>`}</tbody></table>
      <p class="small muted">${esc(t("wg_hint", "v"))}</p>
      <div class="btn-row">${cfgBtn("/cgi-bin/luci/admin/network/network")}</div>
    </div>`);
  };

  VIEWS.wgserver = async function () {
    const d = await apiGet("vpn");
    const rows = arr(d.wireguard).map(w => `<tr><td>${esc(w.iface)}</td><td>${esc(w.port || "-")}</td>
      <td class="small">${esc(w.key || "-")}</td></tr>`).join("");
    return wrap(`<div class="card"><h2>${esc(t("wgserver", "nav"))}</h2>
      <div class="grid">${stat("WireGuard", d.wg_installed ? t("installed") : t("not_installed"))}</div>
      <table><thead><tr><th>${esc(t("wg_iface", "v"))}</th><th>${esc(t("listen_port", "v"))}</th><th>${esc(t("public_key", "v"))}</th></tr></thead>
      <tbody>${rows || `<tr><td colspan="3" class="muted">${esc(t("none"))}</td></tr>`}</tbody></table>
      <p class="small muted">${esc(t("wg_server_hint", "v"))}</p>
      <div class="btn-row">${cfgBtn("/cgi-bin/luci/admin/network/network")}</div>
    </div>`);
  };

  VIEWS.ovpnclient = async function () {
    const [d, o] = await Promise.all([apiGet("vpn"), apiGet("ovpn")]);
    const files = arr(o.files).map(f => `<tr><td>${esc(f)}</td></tr>`).join("");
    return wrap(`<div class="card"><h2>${esc(t("ovpnclient", "nav"))}</h2>
      <div class="grid">${stat("OpenVPN", d.ovpn_installed ? t("installed") : t("not_installed"))}
        ${stat(t("profiles", "v"), o.count || 0)}</div>
      ${serviceBtns("openvpn", "/cgi-bin/luci/admin/vpn/openvpn")}
      <table><thead><tr><th>${esc(t("profiles", "v"))}</th></tr></thead>
      <tbody>${files || `<tr><td class="muted">${esc(t("none"))}</td></tr>`}</tbody></table>
      <p class="small muted">${esc(t("ovpn_hint", "v"))}</p>
    </div>`);
  };
  VIEWS.ovpnclient.mount = bindSvc;

  VIEWS.ovpnserver = async function () {
    const [d, o] = await Promise.all([apiGet("vpn"), apiGet("ovpn")]);
    const files = arr(o.files).map(f => `<tr><td>${esc(f)}</td></tr>`).join("");
    return wrap(`<div class="card"><h2>${esc(t("ovpnserver", "nav"))}</h2>
      <div class="grid">${stat("OpenVPN", d.ovpn_installed ? t("installed") : t("not_installed"))}
        ${stat(t("profiles", "v"), o.count || 0)}</div>
      ${serviceBtns("openvpn", "/cgi-bin/luci/admin/vpn/openvpn")}
      <table><thead><tr><th>${esc(t("profiles", "v"))}</th></tr></thead>
      <tbody>${files || `<tr><td class="muted">${esc(t("none"))}</td></tr>`}</tbody></table>
      <p class="small muted">${esc(t("ovpn_server_hint", "v"))}</p>
    </div>`);
  };
  VIEWS.ovpnserver.mount = bindSvc;

  VIEWS.tor = serviceView("tor", "tor", "/cgi-bin/luci/admin/services/tor");

  VIEWS.tailscale = async function () {
    const d = await apiGet("tailscale");
    return wrap(`<div class="card"><h2>${esc(t("tailscale", "nav"))}</h2>
      <div class="grid">
        ${stat(t("package", "v"), d.installed ? t("installed") : t("not_installed"))}
        ${stat(t("status"), d.backend || t("stopped"))}
        ${stat("Tailscale IP", d.ip || "-")}
      </div>
      ${d.installed ? `<div class="btn-row">
        <button data-tailscale="up">${esc(t("connect"))}</button>
        <button class="ghost" data-tailscale="down">${esc(t("disconnect", "v"))}</button>
        ${cfgBtn("/cgi-bin/luci/admin/network/network")}
      </div>` : ""}
      ${d.status ? `<pre class="log">${esc(d.status)}</pre>` : ""}
      ${!d.installed ? `<p class="small muted">${esc(t("requires_pkg", "v"))}: <code>tailscale</code></p>` : ""}
    </div>`);
  };
  VIEWS.tailscale.mount = function () {
    document.querySelectorAll("[data-tailscale]").forEach(b => {
      b.onclick = async () => {
        const r = await apiPost("tailscale_set", { action: b.getAttribute("data-tailscale") });
        toast(r.ok ? t("saved") : (r.error || t("failed", "v")), r.ok ? "ok" : "err");
        if (r.ok) render();
      };
    });
  };

  VIEWS.zerotier = async function () {
    const d = await apiGet("zerotier");
    return wrap(`<div class="card"><h2>${esc(t("zerotier", "nav"))}</h2>
      <div class="grid">${stat(t("package", "v"), d.installed ? t("installed") : t("not_installed"))}${stat(t("status"), d.running ? t("running") : t("stopped"))}</div>
      <pre class="log">${esc((d.info || "") + "\n" + (d.networks || "")) || esc(t("none"))}</pre>
      <div class="row"><div><label>Network ID</label><input id="zt-nwid" placeholder="8056c2e21c000001"></div></div>
      <div class="btn-row"><button id="zt-join">${esc(t("connect"))}</button>${cfgBtn("/cgi-bin/luci/admin/network/network")}</div>
    </div>`);
  };
  VIEWS.zerotier.mount = function () {
    const b = $("#zt-join");
    if (b) b.onclick = async () => {
      const r = await apiPost("zerotier_set", { action: "join", nwid: $("#zt-nwid").value.trim() });
      toast(r.ok ? t("saved") : t("failed", "v"), r.ok ? "ok" : "err"); render();
    };
  };

  VIEWS.dns = async function () {
    const d = await apiGet("dns");
    return wrap(`<div class="card"><h2>${esc(t("dns", "nav"))}</h2>
      <div><label>${esc(t("upstream_dns", "v"))}</label><input id="dns-servers" value="${esc(d.servers || "")}"></div>
      <p class="small muted">${esc(d.resolv || "")}</p>
      <div class="btn-row"><button id="dns-save">${esc(t("save"))}</button>${cfgBtn("/cgi-bin/luci/admin/network/dhcp")}</div>
    </div>`);
  };
  VIEWS.dns.mount = function () {
    $("#dns-save").onclick = async () => {
      const r = await apiPost("dns_set", { servers: $("#dns-servers").value });
      toast(r.ok ? t("saved") : t("failed", "v"), r.ok ? "ok" : "err");
    };
  };

  VIEWS.ipv6 = async function () {
    const d = await apiGet("ipv6");
    const rows = arr(d.interfaces).map(i => `<tr><td>${esc(i.name)}</td><td>${esc(i.proto || "-")}</td><td class="small">${esc(i.addr || "-")}</td><td>${i.up ? t("on") : t("off")}</td></tr>`).join("");
    return wrap(`<div class="card"><h2>${esc(t("ipv6", "nav"))}</h2>
      <div class="grid">${stat(t("ula", "v"), d.ula || t("none"))}${stat(t("filter_aaaa", "v"), d.filter_aaaa === "1" ? t("on") : t("off"))}</div>
      <table><thead><tr><th>${esc(t("interface", "v"))}</th><th>${esc(t("proto", "v"))}</th><th>IPv6</th><th>${esc(t("status"))}</th></tr></thead>
      <tbody>${rows || `<tr><td colspan="4" class="muted">${esc(t("none"))}</td></tr>`}</tbody></table>
      <pre class="log">${esc(d.nameservers || t("none"))}</pre>
      <div class="btn-row"><a class="ghost" style="padding:9px 16px;border-radius:9px" href="#/dns">${esc(t("dns", "nav"))} ›</a>${cfgBtn("/cgi-bin/luci/admin/network/network")}</div>
    </div>`);
  };

  VIEWS.firewall = async function () {
    const d = await apiGet("firewall");
    const zones = arr(d.zones).map(z => `<tr><td>${esc(z.name)}</td><td>${esc(z.network || "-")}</td><td>${esc(z.input)}</td><td>${esc(z.output)}</td><td>${esc(z.forward)}</td></tr>`).join("");
    const rules = arr(d.rules).map(r => `<tr><td>${esc(r.name || r.idx)}</td><td>${esc(r.src || "-")}</td><td>${esc(r.dest || "-")}</td><td>${esc(r.dest_port || "-")}</td><td>${esc(r.target)}</td></tr>`).join("");
    const fwd = arr(d.forwarding).map(f => `<tr><td>${esc(f.src || "-")}</td><td>${esc(f.dest || "-")}</td></tr>`).join("");
    const def = d.defaults || {};
    return wrap(`<div class="card"><h2>${esc(t("firewall", "nav"))}</h2>
      <div class="grid">
        ${stat(t("rule_count", "v"), d.rule_count || 0)}
        ${stat(t("input", "v"), def.input || "-")}
        ${stat(t("output", "v"), def.output || "-")}
        ${stat(t("forward", "v"), def.forward || "-")}
      </div>
      <table><thead><tr><th>${esc(t("zones", "v"))}</th><th>${esc(t("networks", "v"))}</th><th>${esc(t("input", "v"))}</th><th>${esc(t("output", "v"))}</th><th>${esc(t("forward", "v"))}</th></tr></thead>
      <tbody>${zones || `<tr><td colspan="5" class="muted">${esc(t("none"))}</td></tr>`}</tbody></table>
      <table><thead><tr><th>${esc(t("src", "v"))}</th><th>${esc(t("dest", "v"))}</th></tr></thead>
      <tbody>${fwd || `<tr><td colspan="2" class="muted">${esc(t("none"))}</td></tr>`}</tbody></table>
      <table><thead><tr><th>${esc(t("name"))}</th><th>src</th><th>dest</th><th>${esc(t("port", "v"))}</th><th>${esc(t("rule_target", "v"))}</th></tr></thead>
      <tbody>${rules || `<tr><td colspan="5" class="muted">${esc(t("none"))}</td></tr>`}</tbody></table>
      <p class="small muted">${esc(t("firewall_note", "v"))}</p>
      <div class="btn-row"><a class="ghost" style="padding:9px 16px;border-radius:9px" href="#/ports">${esc(t("ports", "nav"))} ›</a><a class="ghost" style="padding:9px 16px;border-radius:9px" href="#/parental">${esc(t("parental", "nav"))} ›</a>${cfgBtn("/cgi-bin/luci/admin/network/firewall")}</div>
    </div>`);
  };

  VIEWS.vlan = async function () {
    const d = await apiGet("vlan");
    const devs = arr(d.devices).map(x => `<tr><td>${esc(x.name)}</td><td>${esc(x.type)}</td><td>${esc(x.ports || "-")}</td></tr>`).join("");
    const vlans = arr(d.vlans).map(v => `<tr><td>${esc(v.name)}</td><td>${esc(v.vid)}</td></tr>`).join("");
    return wrap(`<div class="card"><h2>${esc(t("vlan", "nav"))}</h2>
      <table><thead><tr><th>${esc(t("devices", "v"))}</th><th>type</th><th>${esc(t("ports", "v"))}</th></tr></thead>
      <tbody>${devs || `<tr><td colspan="3" class="muted">${esc(t("none"))}</td></tr>`}</tbody></table>
      <table><thead><tr><th>802.1Q</th><th>VLAN ID</th></tr></thead>
      <tbody>${vlans || `<tr><td colspan="2" class="muted">${esc(t("none"))}</td></tr>`}</tbody></table>
      <p class="small muted">${esc(t("vlan_note", "v"))}</p>
      <div class="btn-row">${cfgBtn("/cgi-bin/luci/admin/network/network")}</div>
    </div>`);
  };

  VIEWS.upgrade = async function () {
    const [d, u] = await Promise.all([apiGet("overview"), apiGet("upgrades")]);
    const rows = arr(u.upgradable).map(p => `<tr><td>${esc(p.name)}</td><td>${esc(p.to || "-")}</td></tr>`).join("");
    return wrap(`<div class="card"><h2>${esc(t("upgrade", "nav"))}</h2>
      <div class="grid">
        ${stat(t("firmware"), d.firmware, true)}
        ${stat(t("pkgtool", "v"), u.pkgtool || t("none"))}
        ${stat(t("upgradable", "v"), u.count)}
      </div>
      <table><thead><tr><th>${esc(t("package", "v"))}</th><th>${esc(t("new_version", "v"))}</th></tr></thead>
      <tbody>${rows || `<tr><td colspan="2" class="muted">${esc(t("up_to_date", "v"))}</td></tr>`}</tbody></table>
      <p class="small muted">${esc(t("upgrade_note", "v"))}</p>
      ${u.stale ? `<p class="small muted">${esc(t("index_stale", "v"))}</p>` : ""}
      <div class="btn-row">
        <button id="up-refresh">${esc(t("refresh_index", "v"))}</button>
        <a class="ghost" style="padding:9px 16px;border-radius:9px" href="/cgi-bin/luci/admin/system/flash" target="_blank">LuCI Flash</a>
      </div>
    </div>`);
  };
  VIEWS.upgrade.mount = function () {
    const b = $("#up-refresh");
    if (!b) return;
    b.onclick = async () => {
      b.disabled = true;
      b.textContent = t("scanning", "v");
      const r = await apiPost("upgrades_refresh", {});
      b.disabled = false;
      b.textContent = t("refresh_index", "v");
      const last = ((r.output || "").split("\n").filter(Boolean).pop()) || "";
      toast(r.ok ? (last || t("saved")) : (r.error || t("failed", "v")), r.ok ? "ok" : "err");
      render();
    };
  };

  VIEWS.advanced = async function () {
    const d = await apiGet("advanced");
    const s = d.system || {}, dn = d.dns || {}, sy = d.sysctl || {}, g = d.globals || {};
    const kv = (k, v) => `<tr><td>${esc(k)}</td><td class="small">${esc(v || "-")}</td></tr>`;
    return wrap(`<div class="card"><h2>${esc(t("advanced", "nav"))}</h2>
      <div class="grid">
        ${stat(t("hostname"), s.hostname || "-")}
        ${stat(t("timezone", "nav"), s.zonename || s.timezone || "-")}
        ${stat(t("load"), d.load || "-")}
        ${stat(t("swap", "v"), d.swap ? t("on") : t("off"))}
      </div>
      <table><tbody>
        ${kv(t("ntp", "v"), d.ntp)}
        ${kv(t("dns_domain", "v"), dn.domain)}
        ${kv(t("cache_size", "v"), dn.cachesize)}
        ${kv(t("filter_aaaa", "v"), dn.filter_aaaa === "1" ? t("on") : t("off"))}
        ${kv(t("ula", "v"), g.ula_prefix)}
        ${kv(t("swappiness", "v"), sy.swappiness)}
        ${kv(t("netdev_budget", "v"), sy.netdev_budget)}
        ${kv(t("backlog", "v"), sy.backlog)}
        ${kv(t("irqbalance", "v"), d.irqbalance ? t("on") : t("off"))}
        ${kv(t("log_size", "v"), ((s.log_size || "-") + " " + (s.log_proto || "")).trim())}
        ${kv(t("conloglevel", "v"), s.conloglevel)}
        ${kv(t("cronloglevel", "v"), s.cronloglevel)}
        ${kv(t("ttylogin", "v"), s.ttylogin === "1" ? t("on") : t("off"))}
      </tbody></table>
      <div class="row"><div><label>${esc(t("diagnostics", "v"))}</label>
        <input id="diag-host" placeholder="${esc(t("gateway", "v"))}"></div></div>
      <pre class="log" id="diag-out">${esc(t("none"))}</pre>
      <div class="btn-row">
        <button id="diag-run">${esc(t("run", "v"))}</button>
        <a class="ghost" style="padding:9px 16px;border-radius:9px" href="#/mirror">${esc(t("mirror", "nav"))} ›</a>
        ${cfgBtn("/cgi-bin/luci/admin")}
      </div>
    </div>`);
  };
  VIEWS.advanced.mount = function () {
    const b = $("#diag-run");
    if (!b) return;
    b.onclick = async () => {
      const out = $("#diag-out");
      b.disabled = true;
      out.textContent = t("scanning", "v");
      const r = await apiGet("diagnostics", { host: ($("#diag-host").value || "").trim() });
      b.disabled = false;
      out.textContent = r.ok
        ? `${r.host}: ${r.received}/${r.transmitted} · ${r.loss}% ${t("loss", "v")} · min ${r.min} / avg ${r.avg} / max ${r.max} ms`
        : (r.error || t("failed", "v"));
    };
  };

  const KNOWN_PORTS = {
    21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS", 67: "DHCP", 80: "HTTP",
    110: "POP3", 123: "NTP", 139: "SMB", 143: "IMAP", 443: "HTTPS", 445: "SMB",
    514: "Syslog", 631: "CUPS", 853: "DNS over TLS", 9090: "Metrics", 9091: "AdGuard API",
    1194: "OpenVPN", 3000: "TTYD", 7681: "AdGuard UI", 7890: "Clash", 9050: "Tor SOCKS",
    51820: "WireGuard"
  };

  VIEWS.security = async function () {
    const d = await apiGet("security");
    const byPort = {};
    arr(d.listening).forEach(p => { (byPort[p.port] = byPort[p.port] || []).push(p.addr); });
    const ports = Object.keys(byPort).sort((a, b) => Number(a) - Number(b)).map(port => `<tr>
      <td>${esc(port)}</td><td>${esc(KNOWN_PORTS[port] || t("unknown", "v"))}</td>
      <td class="small muted">${esc(byPort[port].join(", "))}</td></tr>`).join("");
    const shell = arr(d.shell_access).map(s => `<tr><td>${esc(s.interface)}</td><td>${esc(s.port)}</td></tr>`).join("");
    return wrap(`<div class="card"><h2>${esc(t("security", "nav"))}</h2>
      <div class="grid">
        ${stat(t("root_password", "v"), d.root_password_locked ? t("pw_locked", "v") : t("pw_set", "v"))}
        ${stat(t("ssh_wan", "v"), d.ssh_wan ? t("on") : t("off"))}
        ${stat(t("web_wan", "v"), d.web_wan ? t("on") : t("off"))}
        ${stat("HTTPS", d.https ? t("on") : t("off"))}
      </div>
      <table><thead><tr><th>${esc(t("shell_access", "v"))}</th><th>${esc(t("port", "v"))}</th></tr></thead>
      <tbody>${shell || `<tr><td colspan="2" class="muted">${esc(t("none"))}</td></tr>`}</tbody></table>
      <table><thead><tr><th>${esc(t("port", "v"))}</th><th>${esc(t("service", "v"))}</th><th>${esc(t("addresses", "v"))}</th></tr></thead>
      <tbody>${ports || `<tr><td colspan="3" class="muted">${esc(t("none"))}</td></tr>`}</tbody></table>
      <p class="small muted">${esc(t("pw_note", "v"))}</p>
      <div class="btn-row">
        <a class="ghost" style="padding:9px 16px;border-radius:9px" href="#/remote">${esc(t("remote", "nav"))} ›</a>
        ${cfgBtn("/cgi-bin/luci/admin/system/admin")}
      </div>
    </div>`);
  };

  VIEWS.backup = async function () {
    const d = await apiGet("backup");
    const files = arr(d.files).map(f => `<tr><td>${esc(f)}</td></tr>`).join("");
    return wrap(`<div class="card"><h2>${esc(t("backup", "nav"))}</h2>
      <div class="grid">
        ${stat(t("config_files", "v"), d.count)}
        ${stat(t("keepfiles", "v"), d.keepfiles)}
        ${stat(t("pkgtool", "v"), d.tool ? "sysupgrade" : t("none"))}
      </div>
      <table><tbody>${files || `<tr><td class="muted">${esc(t("none"))}</td></tr>`}</tbody></table>
      <div class="btn-row">
        <a class="ghost" style="padding:9px 16px;border-radius:9px" href="${esc(d.download || "#")}">${esc(t("download_backup", "v"))}</a>
        ${cfgBtn("/cgi-bin/luci/admin/system/flash")}
      </div>
      <p class="small muted">${esc(t("restore_note", "v"))}</p>
    </div>`);
  };

  VIEWS.parental = async function () {
    const d = await apiGet("parental");
    const rows = arr(d.clients).map(c => `<tr>
      <td>${esc(c.name || "-")}</td><td>${esc(c.mac)}</td><td>${esc(c.ip || "-")}</td>
      <td>${c.blocked ? esc(t("blocked", "v")) : esc(t("allowed", "v"))}</td>
      <td>${c.blocked
        ? `<button class="ghost" data-unblock="${esc(c.mac)}">${esc(t("unblock", "v"))}</button>`
        : `<button data-block="${esc(c.mac)}">${esc(t("block", "v"))}</button>`}</td></tr>`).join("");
    return wrap(`<div class="card"><h2>${esc(t("parental", "nav"))}</h2>
      <table><thead><tr><th>${esc(t("name"))}</th><th>${esc(t("mac", "v"))}</th><th>IP</th>
      <th>${esc(t("status"))}</th><th>${esc(t("action"))}</th></tr></thead>
      <tbody>${rows || `<tr><td colspan="5" class="muted">${esc(t("none"))}</td></tr>`}</tbody></table>
      <p class="small muted">${esc(t("parental_note", "v"))}</p>
      <div class="btn-row">${cfgBtn("/cgi-bin/luci/admin/network/firewall")}</div>
    </div>`);
  };
  VIEWS.parental.mount = function () {
    const run = async (c, mac) => {
      const r = await apiPost(c, { mac });
      toast(r.ok ? t("saved") : (r.error || t("failed", "v")), r.ok ? "ok" : "err");
      if (r.ok) render();
    };
    document.querySelectorAll("[data-block]").forEach(b =>
      b.onclick = () => run("parental_block", b.getAttribute("data-block")));
    document.querySelectorAll("[data-unblock]").forEach(b =>
      b.onclick = () => run("parental_unblock", b.getAttribute("data-unblock")));
  };

  VIEWS.astrowarp = async function () {
    const d = await apiGet("wireguard");
    const names = arr(d.interfaces).map(i => i.name);
    const cards = arr(d.interfaces).map(i => {
      const peers = arr(i.peers).map(p => `<tr>
        <td>${esc(p.name)}</td><td class="small">${esc((p.public_key || "").slice(0, 16))}…</td>
        <td>${esc(p.allowed_ips || "-")}</td><td>${esc(p.endpoint || "-")}</td>
        <td>${p.handshake != null ? esc(p.handshake + "s") : esc(t("never", "v"))}</td>
        <td class="small">${p.rx != null ? esc(human(p.rx) + " / " + human(p.tx)) : "-"}</td>
        <td><button class="ghost" data-wgd="${esc(p.name)}">${esc(t("remove"))}</button></td></tr>`).join("");
      return `<div class="card"><h2>${esc(i.name)}
        <span class="tag ${i.running ? "on" : "off"}">${esc(i.running ? t("running") : t("stopped"))}</span></h2>
        <div class="grid">
          ${stat(t("public_key", "v"), i.public_key || "-")}
          ${stat(t("listen_port", "v"), i.listen_port || "-")}
          ${stat(t("addresses", "v"), i.addresses || "-")}
        </div>
        <table><thead><tr><th>${esc(t("peer", "v"))}</th><th>${esc(t("public_key", "v"))}</th>
          <th>${esc(t("allowed_ips", "v"))}</th><th>${esc(t("endpoint", "v"))}</th>
          <th>${esc(t("handshake", "v"))}</th><th>${esc(t("rate", "v"))}</th><th></th></tr></thead>
        <tbody>${peers || `<tr><td colspan="7" class="muted">${esc(t("none"))}</td></tr>`}</tbody></table>
        <div class="btn-row"><button class="ghost" data-wgd="${esc(i.name)}">${esc(t("remove_interface", "v"))}</button></div>
      </div>`;
    }).join("");

    return wrap(`
      <div class="card"><h2>${esc(t("astrowarp", "nav"))}</h2>
        <p class="small muted">${esc(t("wg_note", "v"))}</p>
        ${cards || `<p class="muted">${esc(t("none"))}</p>`}
      </div>
      <div class="card"><h2>${esc(t("new_interface", "v"))}</h2>
        <div class="row">
          <div><label>${esc(t("name"))}</label><input id="wg-name" value="wg0"></div>
          <div><label>${esc(t("addresses", "v"))}</label><input id="wg-addr" placeholder="10.11.12.1/24"></div>
          <div><label>${esc(t("listen_port", "v"))}</label><input id="wg-port" placeholder="51820"></div>
        </div>
        <div class="btn-row">
          <button id="wg-gen">${esc(t("generate", "v"))}</button>
          <button id="wg-new">${esc(t("create", "v"))}</button>
          ${d.tools ? "" : `<span class="muted small">${esc(t("requires_pkg", "v"))}: <code>wireguard-tools</code></span>`}
        </div>
        <p class="small muted" id="wg-key"></p>
      </div>
      <div class="card"><h2>${esc(t("add_peer", "v"))}</h2>
        <div class="row">
          <div><label>${esc(t("interface", "v"))}</label>
            <select id="wg-if">${names.map(n => `<option value="${esc(n)}">${esc(n)}</option>`).join("")}</select></div>
          <div><label>${esc(t("peer", "v"))}</label><input id="wg-peer" placeholder="laptop"></div>
          <div><label>${esc(t("public_key", "v"))}</label><input id="wg-key-in" placeholder="base64 key"></div>
          <div><label>${esc(t("allowed_ips", "v"))}</label><input id="wg-ips" placeholder="10.11.12.2/32"></div>
        </div>
        <div class="btn-row"><button id="wg-add">${esc(t("add"))}</button></div>
        <p class="small muted">${esc(t("wg_peer_note", "v"))}</p>
      </div>`);
  };
  VIEWS.astrowarp.mount = function () {
    const run = async (res, body) => {
      const r = await apiPost(res, body);
      if (r.ok) { toast(t("saved")); render(); }
      else toast(r.error || t("failed", "v"), "err");
    };
    const gen = $("#wg-gen");
    if (gen) gen.onclick = async () => {
      const r = await apiPost("wireguard_keygen", {});
      if (!r.ok) return toast(r.error || t("failed", "v"), "err");
      // the private key stays on the router; only the public key is shown
      $("#wg-key").textContent = "public key: " + r.public_key;
      const f = $("#wg-key-in");
      if (f) f.value = r.public_key;
    };
    const create = $("#wg-new");
    if (create) create.onclick = () => run("wireguard_new", {
      name: $("#wg-name").value, address: $("#wg-addr").value, port: $("#wg-port").value });
    const add = $("#wg-add");
    if (add) add.onclick = () => run("wireguard_peer", {
      iface: $("#wg-if").value, peer: $("#wg-peer").value,
      public_key: $("#wg-key-in").value, allowed_ip: $("#wg-ips").value });
    document.querySelectorAll("[data-wgd]").forEach(b => {
      b.onclick = () => run("wireguard_del", { name: b.getAttribute("data-wgd") });
    });
  };

  VIEWS.edgerouter = async function () {
    const d = await apiGet("routes");
    const rows = arr(d.routes).map(r => `<tr>
      <td>${esc(r.interface)}</td><td>${esc(r.target)}</td><td>${esc(r.gateway || "-")}</td>
      <td>${esc(r.metric || "-")}</td>
      <td><button class="ghost" data-rdel="${esc(r.section)}">${esc(t("remove"))}</button></td></tr>`).join("");
    const defs = arr(d.default_routes).map(r => `<div class="list-item"><div class="grow"><code>${esc(r)}</code></div></div>`).join("");
    return wrap(`
      <div class="card"><h2>${esc(t("edgerouter", "nav"))}</h2>
        <p class="small muted">${esc(t("route_note", "v"))}</p>
        <table><thead><tr><th>${esc(t("interface", "v"))}</th><th>${esc(t("destination", "v"))}</th>
          <th>${esc(t("gateway", "v"))}</th><th>${esc(t("metric", "v"))}</th><th></th></tr></thead>
        <tbody>${rows || `<tr><td colspan="5" class="muted">${esc(t("none"))}</td></tr>`}</tbody></table>
        <div class="btn-row">${cfgBtn("/cgi-bin/luci/admin/network/routes")}</div>
      </div>
      <div class="card"><h2>${esc(t("default_routes", "v"))}</h2>
        ${defs || `<p class="muted">${esc(t("none"))}</p>`}
        ${d.policy ? `<p class="small muted">${esc(t("policy_note", "v"))}</p>` : ""}
      </div>
      <div class="card"><h2>${esc(t("add_route", "v"))}</h2>
        <div class="row">
          <div><label>${esc(t("interface", "v"))}</label><input id="r-if" placeholder="wan"></div>
          <div><label>${esc(t("destination", "v"))}</label><input id="r-target" placeholder="10.20.0.0/24"></div>
          <div><label>${esc(t("gateway", "v"))}</label><input id="r-gw" placeholder="192.168.1.1"></div>
          <div><label>${esc(t("metric", "v"))}</label><input id="r-metric" placeholder="10"></div>
        </div>
        <div class="btn-row"><button id="r-add">${esc(t("add"))}</button></div>
      </div>`);
  };
  VIEWS.edgerouter.mount = function () {
    const run = async (res, body) => {
      const r = await apiPost(res, body);
      if (r.ok) { toast(t("saved")); render(); } else toast(r.error || t("failed", "v"), "err");
    };
    const add = $("#r-add");
    if (add) add.onclick = () => run("route_add", {
      interface: $("#r-if").value, target: $("#r-target").value,
      gateway: $("#r-gw").value, metric: $("#r-metric").value });
    document.querySelectorAll("[data-rdel]").forEach(b => {
      b.onclick = () => run("route_del", { section: b.getAttribute("data-rdel") });
    });
  };

  /* ---------------- router ---------------- */
  const DEFAULT_ROUTE = "overview";

  function wrap(html) { return `<div class="view-body">${html}</div>`; }

  function currentRoute() {
    const h = (location.hash || "").replace(/^#\/?/, "");
    const key = h.split("/")[0] || DEFAULT_ROUTE;
    return VIEWS[key] ? key : DEFAULT_ROUTE;
  }

  let renderSeq = 0;
  async function render() {
    const key = currentRoute();
    const seq = ++renderSeq;
    $("#page-title").textContent = t(key, "nav");
    document.querySelectorAll(".nav-item").forEach(a =>
      a.classList.toggle("active", a.getAttribute("data-route") === key));
    const view = $("#view");
    view.innerHTML = `<div class="muted">${esc(t("loading"))}</div>`;
    try {
      const fn = VIEWS[key];
      const html = await fn();
      if (seq !== renderSeq) return;
      view.innerHTML = html;
      if (fn.mount) fn.mount();
      const st = $("#status-pill");
      st.className = "pill ok"; st.textContent = t("online", "v");
    } catch (e) {
      if (seq !== renderSeq) return;
      view.innerHTML = `<div class="card"><h2>Error</h2><pre class="log">${esc(e && e.stack || e)}</pre></div>`;
      const st = $("#status-pill"); st.className = "pill bad"; st.textContent = t("error", "v");
    }
  }

  window.addEventListener("hashchange", render);
  let started = false;
  function start() {
    if (started) return; started = true;
    renderNav();
    if (!location.hash) location.hash = "#/" + DEFAULT_ROUTE;
    render();
    const mt = $("#menu-toggle");
    if (mt) mt.onclick = () => $("#sidebar").classList.toggle("open");
    const tt = $("#theme-toggle");
    if (tt) tt.onclick = cycleTheme;
    const tqp = new URLSearchParams(location.search).get("theme");
    if (tqp === "dark" || tqp === "light" || tqp === "auto") localStorage.setItem("wrtweb.theme", tqp);
    applyTheme();
    if (window.matchMedia) {
      const mq = window.matchMedia("(prefers-color-scheme: dark)");
      if (mq.addEventListener) mq.addEventListener("change", () => applyTheme());
    }
    const sw = $("#lang-switch");
    if (sw) sw.onchange = () => setLang(sw.value);
  }
  window.addEventListener("DOMContentLoaded", start);
  if (document.readyState !== "loading") start();
})();
